package com.github.kanesada2.DerbyJockey;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;

final class DerbyHorseCommand implements CommandExecutor, TabCompleter {
    private final DerbyJockey plugin;
    private final DerbyItems items;
    private final HorseStatsService statsService;
    private final HorseRegistry registry;

    DerbyHorseCommand(DerbyJockey plugin, DerbyItems items, HorseStatsService statsService,
                      HorseRegistry registry) {
        this.plugin = plugin;
        this.items = items;
        this.statsService = statsService;
        this.registry = registry;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            showHelp(sender);
            return true;
        }
        if (!sender.hasPermission("derbyjockey.admin")) {
            sender.sendMessage(ChatColor.RED + "権限がありません");
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        try {
            switch (sub) {
                case "save" -> save(sender, args);
                case "restore" -> restore(sender, args, false);
                case "forcesummon" -> restore(sender, args, true);
                case "info", "id" -> info(sender, args);
                case "list" -> list(sender);
                case "delete" -> delete(sender, args);
                case "givewhip" -> giveWhip(sender, args);
                default -> showHelp(sender);
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            sender.sendMessage(ChatColor.RED + ex.getMessage());
        }
        return true;
    }

    private void save(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        Horse horse = selectedHorse(player);
        String id = args.length >= 2
                ? registry.save(args[1], horse, player.getName())
                : registry.ensureRegistered(horse, player.getName());
        sender.sendMessage(ChatColor.GREEN + "馬を保存しました。ID: " + id);
    }

    private void restore(CommandSender sender, String[] args, boolean force) {
        if (args.length < 2) {
            throw new IllegalArgumentException("使い方: /derbyhorse "
                    + (force ? "forcesummon" : "restore") + " <id> [player]");
        }
        if (force && !sender.hasPermission("derbyjockey.admin.force")) {
            throw new IllegalStateException("強制複製の権限がありません");
        }
        Player destination;
        if (args.length >= 3) {
            destination = Bukkit.getPlayerExact(args[2]);
            if (destination == null) {
                throw new IllegalArgumentException("指定プレイヤーがオンラインではありません");
            }
        } else {
            destination = requirePlayer(sender);
        }
        Location location = destination.getLocation();
        Horse horse = registry.restore(args[1], location, sender.getName(), force);
        sender.sendMessage(ChatColor.GREEN + "馬 " + HorseRegistry.normalizeId(args[1])
                + " を " + destination.getName() + " の位置へ召喚しました (UUID "
                + horse.getUniqueId() + ")");
        if (force) {
            sender.sendMessage(ChatColor.RED + "強制複製を監査ログへ記録しました");
        }
    }

    private void info(CommandSender sender, String[] args) {
        if (args.length >= 2) {
            registry.describe(args[1]).forEach(sender::sendMessage);
            return;
        }
        Player player = requirePlayer(sender);
        Horse horse = selectedHorse(player);
        HorseStats stats = statsService.getOrCreate(horse);
        sender.sendMessage(ChatColor.GOLD + "選択中の馬");
        sender.sendMessage(ChatColor.GRAY + "UUID: " + horse.getUniqueId());
        sender.sendMessage(ChatColor.GRAY + "記録ID: "
                + (registry.getRecordId(horse) == null ? "(未登録)" : registry.getRecordId(horse)));
        sender.sendMessage(ChatColor.GRAY + "外観: " + horse.getColor() + " / " + horse.getStyle());
        sender.sendMessage(ChatColor.GRAY + "移動速度: "
                + String.format(Locale.ROOT, "%.3f", stats.baseMovementSpeed())
                + "  跳躍力: " + String.format(Locale.ROOT, "%.3f", horse.getJumpStrength()));
        sender.sendMessage(ChatColor.GRAY + "最大本気度: " + stats.maxSpeedLevel()
                + "  最大スタミナ: "
                + String.format(Locale.ROOT, "%.1f", stats.maxStamina())
                + "  元版補正: " + String.format(Locale.ROOT, "%.2f",
                HorseStatMath.ORIGINAL_BASE_STAMINA / stats.maxStamina()));
        sender.sendMessage(ChatColor.LIGHT_PURPLE + "覚醒確率補正: x"
                + String.format(Locale.ROOT, "%.2f",
                statsService.awakeningChanceMultiplier(stats)));
    }

    private void list(CommandSender sender) {
        List<String> ids = registry.listIds();
        sender.sendMessage(ids.isEmpty() ? ChatColor.GRAY + "保存された馬はいません"
                : ChatColor.GOLD + "保存済み馬: " + ChatColor.WHITE + String.join(", ", ids));
    }

    private void delete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            throw new IllegalArgumentException("使い方: /derbyhorse delete <id>");
        }
        registry.delete(args[1], sender.getName());
        sender.sendMessage(ChatColor.GREEN + "馬記録を削除しました: " + HorseRegistry.normalizeId(args[1]));
    }

    private void giveWhip(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                throw new IllegalArgumentException("指定プレイヤーがオンラインではありません");
            }
        } else {
            target = requirePlayer(sender);
        }
        target.getInventory().addItem(items.createWhip()).values()
                .forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        sender.sendMessage(ChatColor.GREEN + target.getName() + " に鞭を渡しました");
    }

    private Player requirePlayer(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            throw new IllegalArgumentException("コンソールからは対象プレイヤーを指定してください");
        }
        return player;
    }

    private Horse selectedHorse(Player player) {
        if (player.getVehicle() instanceof Horse horse) {
            return horse;
        }
        int distance = Math.max(1, plugin.getConfig().getInt("commands.horse-selection-distance", 8));
        Entity target = player.getTargetEntity(distance, false);
        if (target instanceof Horse horse) {
            return horse;
        }
        throw new IllegalArgumentException("馬に乗るか、" + distance + "ブロック以内の馬へ照準を合わせてください");
    }

    private void showHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "DerbyJockey Modern");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse givewhip [player]" + ChatColor.GRAY + " - 鞭を配布");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse save [id]" + ChatColor.GRAY + " - 自動IDで登録・更新");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse id" + ChatColor.GRAY + " - 選択した馬のIDと能力を確認");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse info [id]" + ChatColor.GRAY + " - 馬の能力・外観を確認");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse list" + ChatColor.GRAY + " - 登録一覧");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse restore <id> [player]" + ChatColor.GRAY + " - 喪失馬を補填");
        sender.sendMessage(ChatColor.RED + "/derbyhorse forcesummon <id> [player]" + ChatColor.GRAY + " - 重複検査を無視");
        sender.sendMessage(ChatColor.YELLOW + "/derbyhorse delete <id>" + ChatColor.GRAY + " - 記録を削除");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("help", "givewhip", "save", "id", "info", "list", "restore",
                    "forcesummon", "delete"), args[0]);
        }
        if (args.length == 2 && List.of("info", "restore", "forcesummon", "delete")
                .contains(args[0].toLowerCase(Locale.ROOT))) {
            return filter(registry.listIds(), args[1]);
        }
        if ((args.length == 2 && args[0].equalsIgnoreCase("givewhip"))
                || (args.length == 3 && (args[0].equalsIgnoreCase("restore")
                || args[0].equalsIgnoreCase("forcesummon")))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(),
                    args[args.length - 1]);
        }
        return List.of();
    }

    private static List<String> filter(List<String> values, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }
}
