package com.github.kanesada2.DerbyJockey;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.EquipmentSlot;

final class DerbyListener implements Listener {
    private final DerbyJockey plugin;
    private final DerbyItems items;
    private final RaceManager raceManager;
    private final HorseRegistry horseRegistry;

    DerbyListener(DerbyJockey plugin, DerbyItems items, RaceManager raceManager,
                  HorseRegistry horseRegistry) {
        this.plugin = plugin;
        this.items = items;
        this.raceManager = raceManager;
        this.horseRegistry = horseRegistry;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnter(VehicleEnterEvent event) {
        if (event.getVehicle() instanceof Horse horse && event.getEntered() instanceof Player player) {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (horse.equals(player.getVehicle())) {
                    if (horse.isTamed() && plugin.getConfig().getBoolean(
                            "storage.auto-register-tamed-horse-on-mount", true)) {
                        horseRegistry.ensureRegistered(horse, "AUTO-MOUNT:" + player.getName());
                    }
                    raceManager.mount(player, horse);
                }
            });
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onExit(VehicleExitEvent event) {
        if (event.getVehicle() instanceof Horse horse && event.getExited() instanceof Player player) {
            raceManager.stop(player);
            if (plugin.getConfig().getBoolean(
                    "storage.auto-update-registered-horse-on-dismount", true)) {
                horseRegistry.updateIfRegistered(horse, "AUTO-DISMOUNT:" + player.getName());
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onWhip(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || !items.isWhip(event.getItem())
                || !(event.getPlayer().getVehicle() instanceof Horse)) {
            return;
        }
        Action action = event.getAction();
        boolean accelerate = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;
        boolean decelerate = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        if ((accelerate || decelerate) && event.getPlayer().hasPermission("derbyjockey.use")
                && raceManager.whip(event.getPlayer(), accelerate)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onTarget(PlayerSwapHandItemsEvent event) {
        if (event.getPlayer().getVehicle() instanceof Horse && raceManager.target(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        raceManager.stop(event.getPlayer());
    }

    @EventHandler
    public void onHorseDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Horse horse) {
            raceManager.stopHorse(horse);
            horseRegistry.auditDeath(horse);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTame(EntityTameEvent event) {
        if (!(event.getEntity() instanceof Horse horse)
                || !plugin.getConfig().getBoolean("storage.auto-register-on-tame", true)) {
            return;
        }
        String ownerName = event.getOwner().getName() == null
                ? event.getOwner().getUniqueId().toString() : event.getOwner().getName();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!horse.isValid()) {
                return;
            }
            String id = horseRegistry.ensureRegistered(horse, "AUTO-TAME:" + ownerName);
            if (event.getOwner() instanceof Player owner) {
                owner.sendMessage(ChatColor.GOLD + "馬を自動登録しました。ID: " + id);
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onNameTag(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Horse horse)
                || !plugin.getConfig().getBoolean("storage.auto-update-on-name-tag", true)) {
            return;
        }
        var inventory = event.getPlayer().getInventory();
        var item = event.getHand() == EquipmentSlot.HAND
                ? inventory.getItemInMainHand() : inventory.getItemInOffHand();
        if (item.getType() != Material.NAME_TAG) {
            return;
        }
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!horse.isValid()) {
                return;
            }
            String id = horseRegistry.ensureRegistered(
                    horse, "AUTO-NAME-TAG:" + event.getPlayer().getName());
            event.getPlayer().sendMessage(ChatColor.GRAY
                    + "馬の名前と保存記録を更新しました。ID: " + id);
        });
    }
}
