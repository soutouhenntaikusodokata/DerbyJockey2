package com.github.kanesada2.DerbyJockey;

record HorseStats(int maxSpeedLevel, double maxStamina, double baseMovementSpeed) {
}
