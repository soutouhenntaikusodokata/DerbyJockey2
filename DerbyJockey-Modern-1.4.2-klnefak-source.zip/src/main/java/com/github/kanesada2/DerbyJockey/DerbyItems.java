package com.github.kanesada2.DerbyJockey;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

final class DerbyItems {
    private static final String TYPE_WHIP = "whip";
    private final DerbyJockey plugin;
    private final NamespacedKey itemTypeKey;
    private final NamespacedKey weightKey;

    DerbyItems(DerbyJockey plugin) {
        this.plugin = plugin;
        this.itemTypeKey = new NamespacedKey(plugin, "item_type");
        this.weightKey = new NamespacedKey(plugin, "armor_weight");
    }

    ItemStack createWhip() {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Horsewhip");
        meta.setLore(List.of(
                ChatColor.GRAY + "DerbyJockey Item",
                ChatColor.AQUA + "左クリック: 加速 / 右クリック: 減速"));
        meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, TYPE_WHIP);
        item.setItemMeta(meta);
        return item;
    }

    ItemStack createWeightedArmor(int weight) {
        ItemStack item = new ItemStack(Material.IRON_HORSE_ARMOR);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.WHITE + "Stamina -" + (weight * 10) + "%");
        meta.setLore(List.of(
                ChatColor.GRAY + "DerbyJockey Item",
                ChatColor.RED + "重量: +" + weight));
        meta.getPersistentDataContainer().set(weightKey, PersistentDataType.INTEGER, weight);
        item.setItemMeta(meta);
        return item;
    }

    boolean isWhip(ItemStack item) {
        if (item == null || item.getType() != Material.STICK || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (TYPE_WHIP.equals(meta.getPersistentDataContainer().get(itemTypeKey, PersistentDataType.STRING))) {
            return true;
        }
        // Accept the original 2020 item so existing whips do not become useless.
        return meta.hasLore() && meta.getLore() != null
                && meta.getLore().stream().map(ChatColor::stripColor)
                .anyMatch("DerbyJockey Item"::equals);
    }

    int getArmorWeight(ItemStack item) {
        if (item == null || item.getType() != Material.IRON_HORSE_ARMOR || !item.hasItemMeta()) {
            return 0;
        }
        Integer modern = item.getItemMeta().getPersistentDataContainer()
                .get(weightKey, PersistentDataType.INTEGER);
        if (modern != null) {
            return Math.max(0, Math.min(8, modern));
        }
        List<String> lore = item.getItemMeta().getLore();
        if (lore == null) {
            return 0;
        }
        for (String line : lore) {
            String plain = ChatColor.stripColor(line);
            if (plain != null && plain.startsWith("impost:+")) {
                try {
                    return Math.max(0, Math.min(8, Integer.parseInt(plain.substring(8))));
                } catch (NumberFormatException ignored) {
                    return 0;
                }
            }
        }
        return 0;
    }

    void registerRecipes() {
        NamespacedKey whipKey = new NamespacedKey(plugin, "horse_whip");
        Bukkit.removeRecipe(whipKey);
        ShapelessRecipe whip = new ShapelessRecipe(whipKey, createWhip());
        whip.addIngredient(Material.STICK);
        whip.addIngredient(Material.LEATHER);
        Bukkit.addRecipe(whip);

        for (int weight = 1; weight <= 8; weight++) {
            NamespacedKey key = new NamespacedKey(plugin, "weighted_armor_" + weight);
            Bukkit.removeRecipe(key);
            ShapelessRecipe recipe = new ShapelessRecipe(key, createWeightedArmor(weight));
            recipe.addIngredient(Material.IRON_HORSE_ARMOR);
            for (int ingot = 0; ingot < weight; ingot++) {
                recipe.addIngredient(Material.IRON_INGOT);
            }
            Bukkit.addRecipe(recipe);
        }
    }
}
