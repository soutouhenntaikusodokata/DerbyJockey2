package com.github.kanesada2.DerbyJockey;

import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.entity.Horse;
import org.bukkit.plugin.java.JavaPlugin;

public final class DerbyJockey extends JavaPlugin {
    private DerbyItems items;
    private HorseStatsService statsService;
    private HorseRegistry horseRegistry;
    private RaceManager raceManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();

        items = new DerbyItems(this);
        statsService = new HorseStatsService(this);
        horseRegistry = new HorseRegistry(this, statsService);
        raceManager = new RaceManager(this, items, statsService, horseRegistry);

        if (getConfig().getBoolean("whip.recipe-enabled", true)) {
            items.registerRecipes();
        }

        DerbyListener listener = new DerbyListener(this, items, raceManager, horseRegistry);
        Bukkit.getPluginManager().registerEvents(listener, this);

        DerbyHorseCommand command = new DerbyHorseCommand(this, items, statsService, horseRegistry);
        Objects.requireNonNull(getCommand("derbyhorse"), "derbyhorse command missing from plugin.yml")
                .setExecutor(command);
        Objects.requireNonNull(getCommand("derbyhorse")).setTabCompleter(command);

        raceManager.startTicker();
        getLogger().info("DerbyJockey Modern enabled for Paper 1.21.8");
    }

    @Override
    public void onDisable() {
        if (horseRegistry != null && getConfig().getBoolean(
                "storage.auto-update-registered-horses-on-shutdown", true)) {
            for (var world : Bukkit.getWorlds()) {
                for (Horse horse : world.getEntitiesByClass(Horse.class)) {
                    horseRegistry.updateIfRegistered(horse, "AUTO-SHUTDOWN");
                }
            }
        }
        if (raceManager != null) {
            raceManager.shutdown();
        }
        if (horseRegistry != null) {
            horseRegistry.flush();
        }
    }
}
