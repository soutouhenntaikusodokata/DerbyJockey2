package com.github.kanesada2.DerbyJockey;

import java.util.Random;

public final class RaceRulesSelfTest {
    public static void main(String[] args) {
        verifyRecoveryRule();
        verifyDrainScaling();
        verifyCompleteDrainFormula();
        verifyVelocityThreshold();
        verifyPositionFallback();
        verifyAwakeningDuration();
        verifyExhaustionDuration();
        System.out.println("RaceRulesSelfTest: PASS");
    }

    private static void verifyRecoveryRule() {
        for (long tick = 1; tick <= 60; tick++) {
            boolean expected = tick % 30 == 0;
            check(RaceRules.isRecoveryTick(0, tick, 30) == expected,
                    "本気度0の30tick回復判定が不正です: " + tick);
            check(!RaceRules.isRecoveryTick(1, tick, 30),
                    "本気度1で回復判定が発生しました");
            check(!RaceRules.isRecoveryTick(-1, tick, 30),
                    "本気度-1で回復判定が発生しました");
        }
        check(close(RaceRules.recoveryAmount(150.0, 0.01), 1.5),
                "最大スタミナの1%になっていません");
    }

    private static void verifyDrainScaling() {
        double previous = 0.0;
        for (int level = 1; level <= 10; level++) {
            double current = RaceRules.drainMultiplier(level, 0.45);
            check(current > previous, "本気度が増えたのに消費倍率が増えていません");
            previous = current;
        }
        check(close(RaceRules.drainMultiplier(1, 0.45), 1.0),
                "本気度1の倍率が不正です");
        check(close(RaceRules.drainMultiplier(2, 0.45), 1.45),
                "本気度2の倍率が不正です");
        check(close(RaceRules.drainMultiplier(6, 0.45), 3.25),
                "本気度6の倍率が3.25倍になっていません");
    }

    private static void verifyCompleteDrainFormula() {
        check(close(RaceRules.drainPerSecond(0.020, 1, 0.45, 0, false), 2.0),
                "本気度1の毎秒消費が2.0ではありません");
        check(close(RaceRules.drainPerSecond(0.020, 6, 0.45, 0, false), 6.5),
                "本気度6の毎秒消費が6.5ではありません");
        check(close(RaceRules.drainPerSecond(0.020, 6, 0.45, 8, false), 11.7),
                "重量8の消費倍率が適用されていません");
        check(close(RaceRules.drainPerSecond(0.020, 6, 0.45, 0, true), 4.55),
                "ドラフティングの30%軽減が適用されていません");
    }

    private static void verifyVelocityThreshold() {
        check(RaceRules.exceedsVelocityThreshold(0.000002, 0.000001),
                "有効な馬速度を検出できません");
        check(!RaceRules.exceedsVelocityThreshold(0.000001, 0.000001),
                "閾値と同値を走行扱いにしています");
        check(!RaceRules.exceedsVelocityThreshold(0.0, 0.000001),
                "停止状態を走行扱いにしています");
        check(RaceRules.isWithinVelocityGrace(105, 100, 5),
                "5tick目の速度検出猶予が維持されていません");
        check(!RaceRules.isWithinVelocityGrace(106, 100, 5),
                "速度検出猶予を超えても走行扱いです");
    }

    private static void verifyPositionFallback() {
        check(RaceRules.isPositionFallbackMovement(0.000002, 0.000001, 4.0),
                "馬速度0時の実移動を検出できません");
        check(!RaceRules.isPositionFallbackMovement(0.000001, 0.000001, 4.0),
                "補完閾値と同値を移動扱いにしています");
        check(!RaceRules.isPositionFallbackMovement(0.0, 0.000001, 4.0),
                "停止状態を実移動扱いにしています");
        check(RaceRules.isPositionFallbackMovement(4.0, 0.000001, 4.0),
                "補完上限と同値の移動を除外しています");
        check(!RaceRules.isPositionFallbackMovement(4.000001, 0.000001, 4.0),
                "テレポート相当の位置変化を走行扱いにしています");
    }

    private static void verifyAwakeningDuration() {
        Random random = new Random(20260720L);
        int observedMinimum = Integer.MAX_VALUE;
        int observedMaximum = Integer.MIN_VALUE;
        for (int index = 0; index < 100000; index++) {
            int duration = RaceRules.awakeningDurationSeconds(random, 20, 50);
            check(duration >= 20 && duration <= 50, "覚醒時間が範囲外です");
            observedMinimum = Math.min(observedMinimum, duration);
            observedMaximum = Math.max(observedMaximum, duration);
        }
        check(observedMinimum == 20 && observedMaximum == 50,
                "覚醒時間の両端が抽選されていません");
    }

    private static void verifyExhaustionDuration() {
        Random random = new Random(20260721L);
        int observedMinimum = Integer.MAX_VALUE;
        int observedMaximum = Integer.MIN_VALUE;
        for (int index = 0; index < 100000; index++) {
            int duration = RaceRules.exhaustionDurationSeconds(random, 25, 45);
            check(duration >= 25 && duration <= 45, "疲労時間が範囲外です");
            observedMinimum = Math.min(observedMinimum, duration);
            observedMaximum = Math.max(observedMaximum, duration);
        }
        check(observedMinimum == 25 && observedMaximum == 45,
                "疲労時間の両端が抽選されていません");
    }

    private static boolean close(double actual, double expected) {
        return Math.abs(actual - expected) < 0.0000001;
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
