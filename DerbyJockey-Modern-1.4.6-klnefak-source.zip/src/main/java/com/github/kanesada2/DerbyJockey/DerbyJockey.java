package com.github.kanesada2.DerbyJockey;

import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.entity.Horse;
import org.bukkit.plugin.java.JavaPlugin;

public final class DerbyJockey extends JavaPlugin {
    private DerbyItems items;
    private HorseStatsService statsService;
    private HorseRegistry horseRegistry;
    private RaceManager raceManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        migrateMovementDetectionDefaults();
        migrateLegacyDrainDefault();
        migrateRaceTimingDefaults();
        saveConfig();

        items = new DerbyItems(this);
        statsService = new HorseStatsService(this);
        horseRegistry = new HorseRegistry(this, statsService);
        raceManager = new RaceManager(this, items, statsService, horseRegistry);

        if (getConfig().getBoolean("whip.recipe-enabled", true)) {
            items.registerRecipes();
        }

        DerbyListener listener = new DerbyListener(this, items, raceManager, horseRegistry);
        Bukkit.getPluginManager().registerEvents(listener, this);

        DerbyHorseCommand command = new DerbyHorseCommand(
                this, items, statsService, horseRegistry, raceManager);
        Objects.requireNonNull(getCommand("derbyhorse"), "derbyhorse command missing from plugin.yml")
                .setExecutor(command);
        Objects.requireNonNull(getCommand("derbyhorse")).setTabCompleter(command);

        raceManager.startTicker();
        getLogger().info("DerbyJockey Modern enabled for Paper 1.21.8");
    }

    private void migrateMovementDetectionDefaults() {
        double current = getConfig().getDouble(
                "stamina.velocity-threshold-squared", 0.000001);
        if (Math.abs(current - 0.0004) < 0.0000000001) {
            getConfig().set("stamina.velocity-threshold-squared", 0.000001);
            getLogger().info("Migrated stamina velocity threshold from 0.0004 to 0.000001");
        }
    }

    private void migrateLegacyDrainDefault() {
        double current = getConfig().getDouble("stamina.drain-per-second", 0.020);
        if (Math.abs(current - 0.012) < 0.0000000001) {
            getConfig().set("stamina.drain-per-second", 0.020);
            getLogger().info("Migrated legacy stamina drain default from 0.012 to 0.020");
        }
    }

    private void migrateRaceTimingDefaults() {
        int recoveryInterval = getConfig().getInt("stamina.recovery-interval-ticks", 30);
        if (recoveryInterval == 5) {
            getConfig().set("stamina.recovery-interval-ticks", 30);
            getLogger().info("Migrated stamina recovery interval from 5 to 30 ticks");
        }

        int exhaustionMinimum = getConfig().getInt(
                "stamina.exhaustion-minimum-duration-seconds", 25);
        int exhaustionMaximum = getConfig().getInt(
                "stamina.exhaustion-maximum-duration-seconds", 45);
        if (exhaustionMinimum == 60 && exhaustionMaximum == 120) {
            getConfig().set("stamina.exhaustion-minimum-duration-seconds", 25);
            getConfig().set("stamina.exhaustion-maximum-duration-seconds", 45);
            getLogger().info("Migrated exhaustion duration from 60-120 to 25-45 seconds");
        }
    }

    @Override
    public void onDisable() {
        if (horseRegistry != null && getConfig().getBoolean(
                "storage.auto-update-registered-horses-on-shutdown", true)) {
            for (var world : Bukkit.getWorlds()) {
                for (Horse horse : world.getEntitiesByClass(Horse.class)) {
                    horseRegistry.updateIfRegistered(horse, "AUTO-SHUTDOWN");
                }
            }
        }
        if (raceManager != null) {
            raceManager.shutdown();
        }
        if (horseRegistry != null) {
            horseRegistry.flush();
        }
    }
}
