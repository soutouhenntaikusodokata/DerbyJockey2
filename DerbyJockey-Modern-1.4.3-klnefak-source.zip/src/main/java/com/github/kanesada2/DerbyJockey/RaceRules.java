package com.github.kanesada2.DerbyJockey;

import java.util.random.RandomGenerator;

final class RaceRules {
    private RaceRules() {
    }

    static boolean isRecoveryTick(int effortLevel, long tick, int intervalTicks) {
        int safeInterval = Math.max(1, intervalTicks);
        return effortLevel == 0 && tick % safeInterval == 0;
    }

    static double recoveryAmount(double maxStamina, double recoveryPercent) {
        return Math.max(0.0, maxStamina) * Math.max(0.0, recoveryPercent);
    }

    static double drainMultiplier(int effortLevel, double perAdditionalLevel) {
        if (effortLevel <= 0) {
            return 0.0;
        }
        return 1.0 + (effortLevel - 1) * Math.max(0.0, perAdditionalLevel);
    }

    static double drainPerSecond(double baseDrainRatio, int effortLevel,
                                 double perAdditionalLevel, int armorWeight,
                                 boolean drafting) {
        double baseDrainPoints = Math.max(0.0, baseDrainRatio) * 100.0;
        double levelMultiplier = drainMultiplier(effortLevel, perAdditionalLevel);
        int safeWeight = Math.max(0, Math.min(8, armorWeight));
        double weightMultiplier = 1.0 + safeWeight * 0.10;
        double draftingMultiplier = drafting ? 0.70 : 1.0;
        return baseDrainPoints * levelMultiplier * weightMultiplier * draftingMultiplier;
    }

    static boolean exceedsVelocityThreshold(double horizontalSpeedSquared,
                                            double thresholdSquared) {
        return Math.max(0.0, horizontalSpeedSquared) > Math.max(0.0, thresholdSquared);
    }

    static boolean isWithinVelocityGrace(long currentTick, long lastDetectedTick,
                                         int graceTicks) {
        return currentTick - lastDetectedTick <= Math.max(0, graceTicks);
    }

    static int awakeningDurationSeconds(RandomGenerator random,
                                        int minimumSeconds, int maximumSeconds) {
        return randomDurationSeconds(random, minimumSeconds, maximumSeconds);
    }

    static int exhaustionDurationSeconds(RandomGenerator random,
                                         int minimumSeconds, int maximumSeconds) {
        return randomDurationSeconds(random, minimumSeconds, maximumSeconds);
    }

    private static int randomDurationSeconds(RandomGenerator random,
                                             int minimumSeconds, int maximumSeconds) {
        int minimum = Math.max(1, minimumSeconds);
        int maximum = Math.max(minimum, maximumSeconds);
        return (int) random.nextLong(minimum, (long) maximum + 1L);
    }
}
