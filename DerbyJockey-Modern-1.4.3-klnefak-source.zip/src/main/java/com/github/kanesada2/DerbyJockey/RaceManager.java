package com.github.kanesada2.DerbyJockey;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Vehicle;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

final class RaceManager {
    private final DerbyJockey plugin;
    private final DerbyItems items;
    private final HorseStatsService statsService;
    private final HorseRegistry horseRegistry;
    private final NamespacedKey exhaustionUntilKey;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private BukkitTask ticker;
    private long tick;

    RaceManager(DerbyJockey plugin, DerbyItems items, HorseStatsService statsService,
                HorseRegistry horseRegistry) {
        this.plugin = plugin;
        this.items = items;
        this.statsService = statsService;
        this.horseRegistry = horseRegistry;
        this.exhaustionUntilKey = new NamespacedKey(plugin, "exhaustion_until_epoch_millis");
    }

    void startTicker() {
        ticker = plugin.getServer().getScheduler().runTaskTimer(plugin, this::clock, 1L, 1L);
    }

    void mount(Player player, Horse horse) {
        stop(player);
        HorseStats stats = statsService.getOrCreate(horse);
        AttributeInstance movement = horse.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement != null) {
            movement.setBaseValue(stats.baseMovementSpeed());
        }
        BossBar bar = plugin.getServer().createBossBar("", BarColor.GREEN, BarStyle.SOLID);
        bar.addPlayer(player);
        Session session = new Session(player, horse, stats, bar);
        restoreExhaustionState(session);
        sessions.put(player.getUniqueId(), session);
        updateBar(session);
        String recordId = horseRegistry.getRecordId(horse);
        player.sendMessage(ChatColor.GOLD + "馬ID: "
                + (recordId == null ? "未登録（手なづけると自動登録）" : recordId));
        player.sendMessage(ChatColor.AQUA + "最大本気度: " + stats.maxSpeedLevel());
        player.sendMessage(ChatColor.AQUA + "最大スタミナ: "
                + String.format(Locale.ROOT, "%.1f", stats.maxStamina())
                + ChatColor.GRAY + "（元版補正 "
                + String.format(Locale.ROOT, "%.2f",
                HorseStatMath.ORIGINAL_BASE_STAMINA / stats.maxStamina()) + "）");
        player.sendMessage(ChatColor.LIGHT_PURPLE + "覚醒確率補正: x"
                + String.format(Locale.ROOT, "%.2f",
                statsService.awakeningChanceMultiplier(stats)));
        player.sendMessage(ChatColor.GRAY + "鞭: 左クリックで加速 / 右クリックで減速");
    }

    boolean whip(Player player, boolean accelerate) {
        Session session = sessions.get(player.getUniqueId());
        if (session == null || !items.isWhip(player.getInventory().getItemInMainHand())) {
            return false;
        }
        int cooldown = Math.max(1, plugin.getConfig().getInt("whip.click-cooldown-ticks", 4));
        if (tick - session.lastWhipTick < cooldown) {
            return true;
        }
        session.lastWhipTick = tick;
        if (accelerate) {
            if (session.exhausted || session.stamina <= 0.0) {
                player.sendActionBar(ChatColor.RED + "疲労困憊：残り "
                        + exhaustionSecondsRemaining(session) + "秒");
                return true;
            }
            session.stamina = Math.max(0.0, session.stamina
                    - ratioToStaminaUnits(plugin.getConfig()
                    .getDouble("stamina.whip-cost", 0.035)));
            player.getWorld().playSound(player.getLocation(),
                    Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
            if (session.stamina <= 0.0) {
                beginExhaustion(session);
                updateBar(session);
                showStatus(session);
                return true;
            }
            if (session.level < session.stats.maxSpeedLevel()) {
                session.level++;
            } else if (!session.awakened) {
                tryAwaken(session, plugin.getConfig()
                        .getDouble("awakening.chance-per-whip-at-max", 0.02));
            }
        } else if (session.awakened) {
            session.awakened = false;
            session.awakeningUntilTick = 0L;
            session.level = session.stats.maxSpeedLevel();
            player.sendActionBar(ChatColor.GRAY + "覚醒を解除しました");
        } else if (session.level > 0) {
            session.level--;
        }
        applySpeed(session);
        updateBar(session);
        showStatus(session);
        return true;
    }

    boolean target(Player player) {
        Session session = sessions.get(player.getUniqueId());
        if (session == null) {
            return false;
        }
        Entity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity entity : session.horse.getNearbyEntities(6, 3, 6)) {
            if (!(entity instanceof Horse || entity instanceof Minecart)) {
                continue;
            }
            double distance = entity.getLocation().distanceSquared(session.horse.getLocation());
            if (distance < bestDistance) {
                best = entity;
                bestDistance = distance;
            }
        }
        if (best == null) {
            session.target = null;
            player.sendActionBar(ChatColor.GRAY + "近くに対象がいません");
        } else {
            session.target = best.getUniqueId();
            session.targetUntilTick = tick + 100;
            player.sendActionBar(ChatColor.RED + "ターゲット: " + best.getName());
        }
        updateBar(session);
        return true;
    }

    List<String> diagnostics(Player player) {
        Session session = sessions.get(player.getUniqueId());
        if (session == null) {
            throw new IllegalStateException("馬へ乗ってから実行してください");
        }
        double thresholdSquared = movementThresholdSquared();
        double levelMultiplier = levelDrainMultiplier(session);
        double expectedDrain = calculateDrainPerSecond(session);
        int armorWeight = items.getArmorWeight(session.horse.getInventory().getArmor());
        return List.of(
                ChatColor.GOLD + "DerbyJockey 消費診断",
                ChatColor.GRAY + "本気度: " + session.level + "/"
                        + session.stats.maxSpeedLevel() + "  消費倍率: x"
                        + format(levelMultiplier),
                ChatColor.GRAY + "水平速度²: " + formatSix(session.horizontalVelocitySquared)
                        + "  閾値: " + formatSix(thresholdSquared),
                ChatColor.GRAY + "走行判定: "
                        + (session.moving ? ChatColor.GREEN + "有効"
                        : ChatColor.RED + "未検出")
                        + ChatColor.GRAY + "  検出猶予: "
                        + movementGraceTicks() + "tick",
                ChatColor.GRAY + "重量: " + armorWeight
                        + "  ドラフティング: " + (hasActiveTarget(session) ? "有効" : "なし"),
                ChatColor.GRAY + "走行時消費: " + format(expectedDrain)
                        + "ポイント/秒  現在適用: "
                        + format(session.moving && !session.exhausted ? expectedDrain : 0.0)
                        + "ポイント/秒",
                ChatColor.DARK_GRAY + "drain-per-second="
                        + plugin.getConfig().getDouble("stamina.drain-per-second", 0.020)
                        + "  additional-level="
                        + plugin.getConfig().getDouble(
                        "stamina.additional-level-drain-multiplier", 0.45));
    }

    void stop(Player player) {
        Session session = sessions.remove(player.getUniqueId());
        if (session != null) {
            restore(session);
        }
    }

    void stopHorse(Horse horse) {
        sessions.values().removeIf(session -> {
            if (!session.horse.getUniqueId().equals(horse.getUniqueId())) {
                return false;
            }
            restore(session);
            return true;
        });
    }

    void shutdown() {
        if (ticker != null) {
            ticker.cancel();
        }
        sessions.values().forEach(this::restore);
        sessions.clear();
    }

    private void clock() {
        tick++;
        sessions.values().removeIf(session -> {
            if (!session.player.isOnline() || !session.horse.isValid()
                    || !session.horse.equals(session.player.getVehicle())) {
                restore(session);
                return true;
            }
            session.moving = isHorseMoving(session);
            session.currentDrainPerSecond = 0.0;
            boolean awakeningEnded = finishAwakeningIfExpired(session);
            finishExhaustionIfExpired(session);

            if (session.moving && session.level > 0 && !session.exhausted) {
                if (!session.awakened && !awakeningEnded
                        && session.level >= session.stats.maxSpeedLevel()
                        && tick % 20 == 0) {
                    tryAwaken(session, plugin.getConfig()
                            .getDouble("awakening.chance-per-second-at-max", 0.01));
                }
                session.currentDrainPerSecond = calculateDrainPerSecond(session);
                session.stamina = Math.max(0.0, session.stamina
                        - session.currentDrainPerSecond / 20.0);
            } else if (RaceRules.isRecoveryTick(
                    session.level,
                    tick,
                    plugin.getConfig().getInt("stamina.recovery-interval-ticks", 5))) {
                double recovery = RaceRules.recoveryAmount(
                        session.stats.maxStamina(),
                        plugin.getConfig().getDouble(
                                "stamina.recovery-percent-per-interval", 0.01));
                session.stamina = Math.min(
                        session.stats.maxStamina(), session.stamina + recovery);
            }

            if (session.stamina <= 0.0 && !session.exhausted) {
                beginExhaustion(session);
            }
            updateBar(session);
            return false;
        });
    }

    private boolean hasActiveTarget(Session session) {
        if (session.target == null || tick > session.targetUntilTick) {
            session.target = null;
            return false;
        }
        Entity target = plugin.getServer().getEntity(session.target);
        return target instanceof Vehicle && target.isValid()
                && target.getWorld().equals(session.horse.getWorld())
                && target.getLocation().distanceSquared(session.horse.getLocation()) <= 100.0;
    }

    private boolean isHorseMoving(Session session) {
        var velocity = session.horse.getVelocity();
        session.horizontalVelocitySquared = velocity.getX() * velocity.getX()
                + velocity.getZ() * velocity.getZ();
        if (RaceRules.exceedsVelocityThreshold(
                session.horizontalVelocitySquared, movementThresholdSquared())) {
            session.lastVelocityMovementTick = tick;
        }
        return RaceRules.isWithinVelocityGrace(
                tick, session.lastVelocityMovementTick, movementGraceTicks());
    }

    private double movementThresholdSquared() {
        return Math.max(0.0, plugin.getConfig()
                .getDouble("stamina.velocity-threshold-squared", 0.000001));
    }

    private int movementGraceTicks() {
        return Math.max(0, plugin.getConfig()
                .getInt("stamina.velocity-detection-grace-ticks", 5));
    }

    private double levelDrainMultiplier(Session session) {
        return RaceRules.drainMultiplier(session.level, plugin.getConfig().getDouble(
                "stamina.additional-level-drain-multiplier", 0.45));
    }

    private double calculateDrainPerSecond(Session session) {
        return RaceRules.drainPerSecond(
                plugin.getConfig().getDouble("stamina.drain-per-second", 0.020),
                session.level,
                plugin.getConfig().getDouble(
                        "stamina.additional-level-drain-multiplier", 0.45),
                items.getArmorWeight(session.horse.getInventory().getArmor()),
                hasActiveTarget(session));
    }

    private boolean finishAwakeningIfExpired(Session session) {
        if (!session.awakened || tick < session.awakeningUntilTick) {
            return false;
        }
        session.awakened = false;
        session.awakeningUntilTick = 0L;
        session.level = session.stats.maxSpeedLevel();
        applySpeed(session);
        session.player.sendActionBar(ChatColor.GRAY + "覚醒が終了しました");
        return true;
    }

    private void beginExhaustion(Session session) {
        session.exhausted = true;
        session.awakened = false;
        session.awakeningUntilTick = 0L;
        session.level = -1;
        session.currentDrainPerSecond = 0.0;
        int durationSeconds = RaceRules.exhaustionDurationSeconds(
                ThreadLocalRandom.current(),
                plugin.getConfig().getInt("stamina.exhaustion-minimum-duration-seconds", 60),
                plugin.getConfig().getInt("stamina.exhaustion-maximum-duration-seconds", 120));
        session.exhaustionUntilEpochMillis = System.currentTimeMillis()
                + durationSeconds * 1000L;
        session.horse.getPersistentDataContainer().set(
                exhaustionUntilKey, PersistentDataType.LONG,
                session.exhaustionUntilEpochMillis);
        applySpeed(session);
        session.player.sendTitle(ChatColor.RED + "疲労困憊",
                ChatColor.WHITE + "本気度 -1 / " + durationSeconds + "秒",
                10, 50, 10);
    }

    private boolean finishExhaustionIfExpired(Session session) {
        if (!session.exhausted
                || System.currentTimeMillis() < session.exhaustionUntilEpochMillis) {
            return false;
        }
        session.exhausted = false;
        session.exhaustionUntilEpochMillis = 0L;
        session.horse.getPersistentDataContainer().remove(exhaustionUntilKey);
        session.level = Math.min(1, session.stats.maxSpeedLevel());
        double recoveryRatio = Math.max(0.0, Math.min(1.0, plugin.getConfig()
                .getDouble("stamina.resume-threshold", 0.25)));
        session.stamina = Math.max(session.stamina,
                session.stats.maxStamina() * recoveryRatio);
        applySpeed(session);
        session.player.sendActionBar(ChatColor.GREEN + "疲労回復：本気度 "
                + session.level + " / スタミナ "
                + Math.round(session.stamina / session.stats.maxStamina() * 100.0) + "%");
        return true;
    }

    private long exhaustionSecondsRemaining(Session session) {
        return session.exhausted
                ? Math.max(0L, (session.exhaustionUntilEpochMillis
                - System.currentTimeMillis() + 999L) / 1000L) : 0L;
    }

    private void restoreExhaustionState(Session session) {
        Long persistedUntil = session.horse.getPersistentDataContainer().get(
                exhaustionUntilKey, PersistentDataType.LONG);
        if (persistedUntil == null) {
            return;
        }
        if (persistedUntil > System.currentTimeMillis()) {
            session.exhausted = true;
            session.exhaustionUntilEpochMillis = persistedUntil;
            session.level = -1;
            session.stamina = 0.0;
        } else {
            session.horse.getPersistentDataContainer().remove(exhaustionUntilKey);
            session.level = Math.min(1, session.stats.maxSpeedLevel());
            double recoveryRatio = Math.max(0.0, Math.min(1.0, plugin.getConfig()
                    .getDouble("stamina.resume-threshold", 0.25)));
            session.stamina = session.stats.maxStamina() * recoveryRatio;
        }
        applySpeed(session);
    }

    private boolean tryAwaken(Session session, double baseChance) {
        if (!plugin.getConfig().getBoolean("awakening.enabled", true)
                || session.awakened || session.exhausted
                || session.level < session.stats.maxSpeedLevel()) {
            return false;
        }
        double modifiedChance = baseChance
                * statsService.awakeningChanceMultiplier(session.stats);
        double safeChance = Math.max(0.0, Math.min(1.0, modifiedChance));
        if (ThreadLocalRandom.current().nextDouble() >= safeChance) {
            return false;
        }
        session.awakened = true;
        session.level = session.stats.maxSpeedLevel() + 1;
        session.stamina = session.stats.maxStamina();
        int durationSeconds = RaceRules.awakeningDurationSeconds(
                ThreadLocalRandom.current(),
                plugin.getConfig().getInt("awakening.minimum-duration-seconds", 20),
                plugin.getConfig().getInt("awakening.maximum-duration-seconds", 50));
        session.awakeningUntilTick = tick + durationSeconds * 20L;
        applySpeed(session);
        session.player.getWorld().playSound(session.player.getLocation(),
                Sound.ITEM_TOTEM_USE, 1.0f, 1.1f);
        session.player.sendTitle(ChatColor.LIGHT_PURPLE + "覚醒！",
                ChatColor.WHITE + "本気度 " + session.level + " / "
                        + durationSeconds + "秒 / スタミナ全回復",
                10, 50, 10);
        updateBar(session);
        return true;
    }

    private void applySpeed(Session session) {
        AttributeInstance movement = session.horse.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement == null) {
            return;
        }
        double factor;
        if (session.level < 0) {
            factor = plugin.getConfig().getDouble("whip.slow-speed-multiplier", 0.75);
        } else {
            factor = 1.0 + session.level
                    * plugin.getConfig().getDouble("whip.speed-per-level", 0.12);
        }
        movement.setBaseValue(Math.min(1.0, session.stats.baseMovementSpeed() * factor));
    }

    private void restore(Session session) {
        session.bar.removeAll();
        if (session.horse.isValid()) {
            AttributeInstance movement = session.horse.getAttribute(Attribute.MOVEMENT_SPEED);
            if (movement != null) {
                movement.setBaseValue(session.stats.baseMovementSpeed());
            }
        }
    }

    private void updateBar(Session session) {
        double staminaRatio = session.stamina / session.stats.maxStamina();
        session.bar.setProgress(Math.max(0.0, Math.min(1.0, staminaRatio)));
        session.bar.setColor(session.awakened ? BarColor.PINK
                : session.exhausted ? BarColor.RED
                : hasActiveTarget(session) ? BarColor.YELLOW : BarColor.GREEN);
        String name = session.horse.getCustomName() == null ? "Horse" : session.horse.getCustomName();
        String id = horseRegistry.getRecordId(session.horse);
        long staminaPercent = Math.round(staminaRatio * 100.0);
        long awakeningSeconds = session.awakened
                ? Math.max(0L, (session.awakeningUntilTick - tick + 19L) / 20L) : 0L;
        long exhaustionSeconds = exhaustionSecondsRemaining(session);
        double levelMultiplier = levelDrainMultiplier(session);
        session.bar.setTitle(name + ChatColor.GRAY + " [ID " + (id == null ? "未登録" : id) + "]"
                + ChatColor.AQUA + "  本気度 " + session.level + "/" + session.stats.maxSpeedLevel()
                + (session.level > 0 ? " x" + format(levelMultiplier) : "")
                + ChatColor.GREEN + "  スタミナ " + Math.round(session.stamina)
                + "/" + Math.round(session.stats.maxStamina()) + " (" + staminaPercent + "%)"
                + (session.level > 0 && !session.exhausted
                ? session.moving
                ? ChatColor.RED + "  -" + format(session.currentDrainPerSecond) + "/秒"
                : ChatColor.GRAY + "  速度未検出" : "")
                + (session.awakened ? ChatColor.LIGHT_PURPLE
                + "  覚醒 " + awakeningSeconds + "秒" : "")
                + (session.exhausted ? ChatColor.RED
                + "  疲労困憊 " + exhaustionSeconds + "秒" : ""));
    }

    private void showStatus(Session session) {
        long awakeningSeconds = session.awakened
                ? Math.max(0L, (session.awakeningUntilTick - tick + 19L) / 20L) : 0L;
        long exhaustionSeconds = exhaustionSecondsRemaining(session);
        double levelMultiplier = levelDrainMultiplier(session);
        double expectedDrain = calculateDrainPerSecond(session);
        session.player.sendActionBar(ChatColor.AQUA + "本気度 " + session.level
                + ChatColor.GRAY + " | " + ChatColor.GREEN + "スタミナ "
                + Math.round(session.stamina) + "/" + Math.round(session.stats.maxStamina())
                + " (" + Math.round(session.stamina / session.stats.maxStamina() * 100.0) + "%)"
                + (session.awakened ? ChatColor.LIGHT_PURPLE
                + " | 覚醒残り " + awakeningSeconds + "秒" : "")
                + (session.exhausted ? ChatColor.RED
                + " | 疲労残り " + exhaustionSeconds + "秒" : "")
                + (session.level > 0 && !session.exhausted ? ChatColor.YELLOW
                + " | 消費x" + format(levelMultiplier) + " "
                + format(session.moving ? expectedDrain : 0.0) + "/秒"
                + (session.moving ? "" : "（速度未検出）") : ""));
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private static String formatSix(double value) {
        return String.format(Locale.ROOT, "%.6f", value);
    }

    private static double ratioToStaminaUnits(double ratio) {
        return Math.max(0.0, ratio) * 100.0;
    }

    private static final class Session {
        private final Player player;
        private final Horse horse;
        private final HorseStats stats;
        private final BossBar bar;
        private int level;
        private double stamina;
        private boolean exhausted;
        private long exhaustionUntilEpochMillis;
        private boolean awakened;
        private long awakeningUntilTick;
        private long lastWhipTick = Long.MIN_VALUE / 2;
        private long lastVelocityMovementTick = Long.MIN_VALUE / 2;
        private double horizontalVelocitySquared;
        private boolean moving;
        private double currentDrainPerSecond;
        private UUID target;
        private long targetUntilTick;

        private Session(Player player, Horse horse, HorseStats stats, BossBar bar) {
            this.player = player;
            this.horse = horse;
            this.stats = stats;
            this.bar = bar;
            this.stamina = stats.maxStamina();
        }
    }
}
