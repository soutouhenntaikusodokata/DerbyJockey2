package com.github.kanesada2.DerbyJockey;

import java.util.UUID;

public final class HorseStatMathSelfTest {
    public static void main(String[] args) {
        verifyCapacityRange();
        verifyOriginalDeclaredDurationEquivalence();
        verifyUuidModifierRoundTrip();
        System.out.println("HorseStatMathSelfTest: PASS");
    }

    private static void verifyCapacityRange() {
        check(close(HorseStatMath.MODERN_BASE_STAMINA, 400.0),
                "現行基準容量が400ではありません");
        check(close(HorseStatMath.minimumOriginalMaxStamina(), 400.0),
                "最小スタミナが400ではありません");
        check(close(HorseStatMath.maximumOriginalMaxStamina(), 400.0 / 0.55),
                "最大スタミナが約727.27ではありません");
    }

    private static void verifyOriginalDeclaredDurationEquivalence() {
        double[] modifiers = {1.0, 0.75, 0.55};
        for (double modifier : modifiers) {
            double capacity = HorseStatMath.MODERN_BASE_STAMINA / modifier;
            double original = HorseStatMath.originalDeclaredDurationSeconds(modifier);
            double modern = HorseStatMath.modernDefaultLevelOneDurationSeconds(capacity);
            check(close(original, modern),
                    "元版表示時間と現行本気度1の継続時間が一致しません: " + modifier);
        }
        check(close(HorseStatMath.originalDeclaredDurationSeconds(1.0), 200.0),
                "補正1.00の継続時間が200秒ではありません");
        check(close(HorseStatMath.originalDeclaredDurationSeconds(0.55),
                200.0 / 0.55), "補正0.55の継続時間が約363.64秒ではありません");
    }

    private static void verifyUuidModifierRoundTrip() {
        UUID id = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        double modifier = HorseStatMath.originalStaminaModifier(id, 30.0);
        double capacity = HorseStatMath.originalEffectiveMaxStamina(id, 30.0);
        check(modifier >= 0.55 && modifier <= 1.0,
                "UUID補正が0.55～1.00の範囲外です");
        check(close(HorseStatMath.staminaModifierFromCapacity(capacity), modifier),
                "容量から元版補正を復元できません");
    }

    private static boolean close(double actual, double expected) {
        return Math.abs(actual - expected) < 0.0000001;
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
