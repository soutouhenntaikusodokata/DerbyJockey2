package com.github.kanesada2.DerbyJockey;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Horse;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

final class HorseRegistry {
    private static final String ID_PATTERN = "[a-z0-9_-]{1,32}";
    private static final String STAMINA_MODEL = "original-declared-duration-v2";
    private final DerbyJockey plugin;
    private final HorseStatsService statsService;
    private final File databaseFile;
    private final File auditFile;
    private final YamlConfiguration database;
    private final NamespacedKey recordIdKey;
    private final SecureRandom random = new SecureRandom();

    HorseRegistry(DerbyJockey plugin, HorseStatsService statsService) {
        this.plugin = plugin;
        this.statsService = statsService;
        plugin.getDataFolder().mkdirs();
        databaseFile = new File(plugin.getDataFolder(), "horse-records.yml");
        auditFile = new File(plugin.getDataFolder(), "horse-audit.log");
        database = YamlConfiguration.loadConfiguration(databaseFile);
        recordIdKey = new NamespacedKey(plugin, "horse_record_id");
    }

    static String normalizeId(String raw) {
        return raw.toLowerCase(Locale.ROOT);
    }

    static boolean validId(String id) {
        return id != null && id.matches(ID_PATTERN);
    }

    synchronized String save(String rawId, Horse horse, String actor) {
        String id = normalizeId(rawId);
        if (!validId(id)) {
            throw new IllegalArgumentException("IDは英小文字・数字・_・-のみ、1～32文字です");
        }
        String currentId = getRecordId(horse);
        if (currentId != null && exists(currentId) && !currentId.equals(id)) {
            throw new IllegalStateException("この馬には既にID " + currentId + " があります");
        }
        if (exists(id) && !id.equals(currentId)) {
            throw new IllegalStateException("ID " + id + " は別の馬が使用中です");
        }
        if (isIdUsedByOtherLoadedHorse(id, horse)) {
            throw new IllegalStateException("ID " + id + " はロード済みの別の馬が使用中です");
        }
        horse.getPersistentDataContainer().set(recordIdKey, PersistentDataType.STRING, id);
        writeRecord(id, horse, actor);
        flush();
        audit("SAVE", id, actor, horse.getLocation());
        return id;
    }

    synchronized String ensureRegistered(Horse horse, String actor) {
        String currentId = getRecordId(horse);
        if (currentId != null && exists(currentId)) {
            writeRecord(currentId, horse, actor);
            flush();
            return currentId;
        }
        if (currentId != null && validId(currentId) && !currentId.contains("-copy-")
                && !isIdUsedByOtherLoadedHorse(currentId, horse)) {
            return save(currentId, horse, actor);
        }
        return save(generateUniqueNumericId(), horse, actor);
    }

    synchronized String generateUniqueNumericId() {
        long minimum = Math.max(0, plugin.getConfig().getLong("horse-id.minimum", 100000));
        long maximum = Math.max(minimum, plugin.getConfig().getLong("horse-id.maximum", 999999));
        long range = maximum - minimum + 1;
        if (range <= 0) {
            throw new IllegalStateException("horse-idの範囲が大きすぎます");
        }
        for (int attempt = 0; attempt < 10000; attempt++) {
            String candidate = Long.toString(minimum + random.nextLong(range));
            if (!exists(candidate) && findLoaded(candidate) == null) {
                return candidate;
            }
        }
        throw new IllegalStateException("空いている馬IDを生成できませんでした。ID範囲を広げてください");
    }

    synchronized boolean updateIfRegistered(Horse horse, String actor) {
        String id = getRecordId(horse);
        if (id == null || !exists(id)) {
            return false;
        }
        writeRecord(id, horse, actor);
        flush();
        return true;
    }

    String getRecordId(Horse horse) {
        return horse.getPersistentDataContainer().get(recordIdKey, PersistentDataType.STRING);
    }

    synchronized boolean exists(String rawId) {
        return database.isConfigurationSection("horses." + normalizeId(rawId));
    }

    synchronized List<String> listIds() {
        ConfigurationSection section = database.getConfigurationSection("horses");
        if (section == null) {
            return List.of();
        }
        return new ArrayList<>(section.getKeys(false)).stream().sorted().toList();
    }

    synchronized void delete(String rawId, String actor) {
        String id = normalizeId(rawId);
        if (!exists(id)) {
            throw new IllegalArgumentException("そのIDの馬記録はありません");
        }
        for (World world : Bukkit.getWorlds()) {
            for (Horse horse : world.getEntitiesByClass(Horse.class)) {
                if (id.equals(getRecordId(horse))) {
                    horse.getPersistentDataContainer().remove(recordIdKey);
                }
            }
        }
        database.set("horses." + id, null);
        flush();
        audit("DELETE", id, actor, null);
    }

    Horse findLoaded(String rawId) {
        String id = normalizeId(rawId);
        for (World world : Bukkit.getWorlds()) {
            for (Horse horse : world.getEntitiesByClass(Horse.class)) {
                if (id.equals(getRecordId(horse))) {
                    return horse;
                }
            }
        }
        return null;
    }

    private boolean isIdUsedByOtherLoadedHorse(String id, Horse selected) {
        for (World world : Bukkit.getWorlds()) {
            for (Horse horse : world.getEntitiesByClass(Horse.class)) {
                if (!horse.getUniqueId().equals(selected.getUniqueId())
                        && id.equals(getRecordId(horse))) {
                    return true;
                }
            }
        }
        return false;
    }

    synchronized Horse restore(String rawId, Location location, String actor, boolean force) {
        String id = normalizeId(rawId);
        ConfigurationSection section = database.getConfigurationSection("horses." + id);
        if (section == null) {
            throw new IllegalArgumentException("そのIDの馬記録はありません");
        }
        Horse loaded = findLoaded(id);
        if (loaded != null && !force) {
            Location at = loaded.getLocation();
            throw new IllegalStateException("同じ記録IDの馬がロード済みです: "
                    + at.getWorld().getName() + " " + at.getBlockX() + " "
                    + at.getBlockY() + " " + at.getBlockZ());
        }

        Horse horse = location.getWorld().spawn(location, Horse.class);
        try {
            applyRecord(section, horse, id);
            if (force) {
                String copyId = id + "-copy-" + horse.getUniqueId().toString().substring(0, 8);
                horse.getPersistentDataContainer().set(
                        recordIdKey, PersistentDataType.STRING, copyId);
            }
        } catch (RuntimeException ex) {
            horse.remove();
            throw ex;
        }
        audit(force ? "FORCE-RESTORE" : "RESTORE", id, actor, location);
        return horse;
    }

    synchronized List<String> describe(String rawId) {
        String id = normalizeId(rawId);
        ConfigurationSection s = database.getConfigurationSection("horses." + id);
        if (s == null) {
            throw new IllegalArgumentException("そのIDの馬記録はありません");
        }
        HorseStats stats = new HorseStats(
                Math.max(1, s.getInt("derby.max-speed-level", 4)),
                storedMaxStamina(s),
                Math.max(0.001, s.getDouble("attributes.movement-speed", 0.225)));
        return List.of(
                ChatColor.GOLD + "馬記録: " + id,
                ChatColor.GRAY + "名前: " + s.getString("name", "(なし)"),
                ChatColor.GRAY + "外観: " + s.getString("appearance.color", "不明")
                        + " / " + s.getString("appearance.style", "不明"),
                ChatColor.GRAY + "体力: " + format(s.getDouble("attributes.health"))
                        + "/" + format(s.getDouble("attributes.max-health")),
                ChatColor.GRAY + "移動速度: " + format(s.getDouble("attributes.movement-speed"))
                        + "  跳躍力: " + format(s.getDouble("attributes.jump-strength")),
                ChatColor.GRAY + "Derby: 最大本気度 " + stats.maxSpeedLevel()
                        + " / 最大スタミナ " + format(stats.maxStamina())
                        + " / 元版補正 " + format(
                        HorseStatMath.staminaModifierFromCapacity(stats.maxStamina())),
                ChatColor.LIGHT_PURPLE + "覚醒確率補正: x"
                        + format(statsService.awakeningChanceMultiplier(stats)),
                ChatColor.DARK_GRAY + "保存者: " + s.getString("saved.by", "不明")
                        + "  保存日時: " + s.getString("saved.at", "不明"));
    }

    void auditDeath(Horse horse) {
        String id = getRecordId(horse);
        if (id != null) {
            audit("DEATH", id, "SYSTEM", horse.getLocation());
        }
    }

    synchronized void flush() {
        try {
            database.save(databaseFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save horse-records.yml", ex);
        }
    }

    private void writeRecord(String id, Horse horse, String actor) {
        String root = "horses." + id;
        database.set(root, null);
        database.set(root + ".schema", 3);
        database.set(root + ".saved.at", Instant.now().toString());
        database.set(root + ".saved.by", actor);
        database.set(root + ".source-uuid", horse.getUniqueId().toString());
        database.set(root + ".name", horse.getCustomName());
        database.set(root + ".name-visible", horse.isCustomNameVisible());
        database.set(root + ".appearance.color", horse.getColor().name());
        database.set(root + ".appearance.style", horse.getStyle().name());
        database.set(root + ".age.adult", horse.isAdult());
        database.set(root + ".age.ticks", horse.getAge());
        database.set(root + ".age.age-lock", horse.getAgeLock());
        database.set(root + ".taming.tamed", horse.isTamed());
        database.set(root + ".taming.domestication", horse.getDomestication());
        database.set(root + ".taming.max-domestication", horse.getMaxDomestication());
        if (horse.getOwner() != null) {
            database.set(root + ".taming.owner", horse.getOwner().getUniqueId().toString());
        }
        AttributeInstance maxHealth = horse.getAttribute(Attribute.MAX_HEALTH);
        AttributeInstance movement = horse.getAttribute(Attribute.MOVEMENT_SPEED);
        database.set(root + ".attributes.max-health", maxHealth == null ? 30.0 : maxHealth.getBaseValue());
        database.set(root + ".attributes.health", Math.max(1.0, horse.getHealth()));
        HorseStats stats = statsService.getOrCreate(horse);
        database.set(root + ".attributes.movement-speed", stats.baseMovementSpeed());
        database.set(root + ".attributes.jump-strength", horse.getJumpStrength());
        database.set(root + ".derby.max-speed-level", stats.maxSpeedLevel());
        database.set(root + ".derby.max-stamina", stats.maxStamina());
        database.set(root + ".derby.stamina-model", STAMINA_MODEL);
        database.set(root + ".derby.stamina-modifier",
                HorseStatMath.staminaModifierFromCapacity(stats.maxStamina()));
        database.set(root + ".derby.endurance",
                stats.maxStamina() / HorseStatMath.MODERN_BASE_STAMINA);
        database.set(root + ".inventory.saddle", cloneOrNull(horse.getInventory().getSaddle()));
        database.set(root + ".inventory.armor", cloneOrNull(horse.getInventory().getArmor()));
        database.set(root + ".flags.ai", horse.hasAI());
        database.set(root + ".flags.invulnerable", horse.isInvulnerable());
        database.set(root + ".flags.silent", horse.isSilent());
        database.set(root + ".flags.glowing", horse.isGlowing());
        database.set(root + ".flags.gravity", horse.hasGravity());
        database.set(root + ".flags.persistent", horse.isPersistent());
    }

    private void applyRecord(ConfigurationSection s, Horse horse, String id) {
        horse.getPersistentDataContainer().set(recordIdKey, PersistentDataType.STRING, id);
        horse.setColor(parseEnum(Horse.Color.class, s.getString("appearance.color"), Horse.Color.BROWN));
        horse.setStyle(parseEnum(Horse.Style.class, s.getString("appearance.style"), Horse.Style.NONE));
        horse.setCustomName(s.getString("name"));
        horse.setCustomNameVisible(s.getBoolean("name-visible", false));
        horse.setAgeLock(s.getBoolean("age.age-lock", false));
        int age = s.contains("age.ticks") ? s.getInt("age.ticks")
                : s.getBoolean("age.adult", true) ? 0 : -24000;
        horse.setAge(age);

        int maxDomestication = Math.max(1, s.getInt("taming.max-domestication", 100));
        horse.setMaxDomestication(maxDomestication);
        horse.setDomestication(Math.max(1,
                Math.min(maxDomestication, s.getInt("taming.domestication", maxDomestication))));
        horse.setTamed(s.getBoolean("taming.tamed", true));
        String ownerId = s.getString("taming.owner");
        if (ownerId != null && !ownerId.isBlank()) {
            try {
                OfflinePlayer owner = Bukkit.getOfflinePlayer(UUID.fromString(ownerId));
                horse.setOwner(owner);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Invalid owner UUID in horse record " + id + ": " + ownerId);
            }
        }

        double maxHealthValue = Math.max(1.0, s.getDouble("attributes.max-health", 30.0));
        AttributeInstance maxHealth = horse.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(maxHealthValue);
        }
        horse.setHealth(Math.max(1.0,
                Math.min(maxHealthValue, s.getDouble("attributes.health", maxHealthValue))));
        double movementSpeed = Math.max(0.001, s.getDouble("attributes.movement-speed", 0.225));
        AttributeInstance movement = horse.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement != null) {
            movement.setBaseValue(movementSpeed);
        }
        horse.setJumpStrength(Math.max(0.0,
                Math.min(2.0, s.getDouble("attributes.jump-strength", 0.7))));
        HorseStats stats = new HorseStats(
                Math.max(1, s.getInt("derby.max-speed-level", 4)),
                storedMaxStamina(s),
                movementSpeed);
        statsService.apply(horse, stats);

        horse.getInventory().setSaddle(s.getItemStack("inventory.saddle"));
        horse.getInventory().setArmor(s.getItemStack("inventory.armor"));
        horse.setAI(s.getBoolean("flags.ai", true));
        horse.setInvulnerable(s.getBoolean("flags.invulnerable", false));
        horse.setSilent(s.getBoolean("flags.silent", false));
        horse.setGlowing(s.getBoolean("flags.glowing", false));
        horse.setGravity(s.getBoolean("flags.gravity", true));
        horse.setPersistent(s.getBoolean("flags.persistent", true));
    }

    private void audit(String action, String id, String actor, Location location) {
        String where = location == null ? "-" : location.getWorld().getName() + ","
                + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
        String line = Instant.now() + "\t" + action + "\t" + id + "\t" + actor + "\t" + where
                + System.lineSeparator();
        try {
            Files.writeString(auditFile.toPath(), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Could not write horse-audit.log", ex);
        }
    }

    private static ItemStack cloneOrNull(ItemStack item) {
        return item == null || item.getType().isAir() ? null : item.clone();
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.3f", value);
    }

    private static double storedMaxStamina(ConfigurationSection section) {
        if (STAMINA_MODEL.equals(section.getString("derby.stamina-model"))
                && section.contains("derby.max-stamina")) {
            return Math.max(1.0, section.getDouble("derby.max-stamina", 100.0));
        }
        String sourceId = section.getString("source-uuid");
        if (sourceId != null) {
            try {
                return HorseStatMath.originalEffectiveMaxStamina(
                        UUID.fromString(sourceId),
                        section.getDouble("attributes.max-health", 30.0));
            } catch (IllegalArgumentException ignored) {
                // 破損した旧記録は、下の互換値へフォールバックする。
            }
        }
        if (section.contains("derby.max-stamina")) {
            return Math.max(1.0, section.getDouble("derby.max-stamina", 100.0));
        }
        return Math.max(1.0, section.getDouble("derby.endurance", 1.0) * 100.0);
    }

    private static <T extends Enum<T>> T parseEnum(Class<T> type, String value, T fallback) {
        if (value == null) {
            return fallback;
        }
        try {
            return Enum.valueOf(type, value);
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }
}
