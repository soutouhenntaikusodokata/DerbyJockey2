package com.github.kanesada2.DerbyJockey;

import java.util.Random;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Horse;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

final class HorseStatsService {
    private static final int CURRENT_STAMINA_MODEL = 2;
    private final DerbyJockey plugin;
    private final NamespacedKey maxLevelKey;
    private final NamespacedKey maxStaminaKey;
    private final NamespacedKey staminaModelKey;
    private final NamespacedKey enduranceKey;
    private final NamespacedKey baseSpeedKey;

    HorseStatsService(DerbyJockey plugin) {
        this.plugin = plugin;
        maxLevelKey = new NamespacedKey(plugin, "max_speed_level");
        maxStaminaKey = new NamespacedKey(plugin, "max_stamina");
        staminaModelKey = new NamespacedKey(plugin, "stamina_model");
        enduranceKey = new NamespacedKey(plugin, "endurance");
        baseSpeedKey = new NamespacedKey(plugin, "base_movement_speed");
    }

    HorseStats getOrCreate(Horse horse) {
        PersistentDataContainer pdc = horse.getPersistentDataContainer();
        Integer maxLevel = pdc.get(maxLevelKey, PersistentDataType.INTEGER);
        Double maxStamina = pdc.get(maxStaminaKey, PersistentDataType.DOUBLE);
        Integer staminaModel = pdc.get(staminaModelKey, PersistentDataType.INTEGER);
        Double baseSpeed = pdc.get(baseSpeedKey, PersistentDataType.DOUBLE);

        AttributeInstance movement = horse.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement == null) {
            throw new IllegalStateException("Horse has no movement-speed attribute");
        }
        int minLevel = minimumSpeedLevel();
        int maxConfigured = maximumSpeedLevel();
        if (maxLevel == null) {
            Random random = randomFor(horse);
            maxLevel = HorseStatMath.middleBiasedInt(random, minLevel, maxConfigured);
        }
        if (maxStamina == null || staminaModel == null
                || staminaModel < CURRENT_STAMINA_MODEL) {
            // 元版が騎乗時に表示した継続時間と、現行の標準本気度1消費を一致させる。
            AttributeInstance maxHealth = horse.getAttribute(Attribute.MAX_HEALTH);
            maxStamina = HorseStatMath.originalEffectiveMaxStamina(
                    horse.getUniqueId(), maxHealth == null ? 30.0 : maxHealth.getValue());
        }
        if (baseSpeed == null || baseSpeed <= 0) {
            baseSpeed = movement.getBaseValue();
        }
        HorseStats stats = new HorseStats(maxLevel, maxStamina, baseSpeed);
        apply(horse, stats);
        return stats;
    }

    void apply(Horse horse, HorseStats stats) {
        PersistentDataContainer pdc = horse.getPersistentDataContainer();
        pdc.set(maxLevelKey, PersistentDataType.INTEGER, Math.max(1, stats.maxSpeedLevel()));
        double safeMaxStamina = Math.max(1.0, stats.maxStamina());
        pdc.set(maxStaminaKey, PersistentDataType.DOUBLE, safeMaxStamina);
        pdc.set(staminaModelKey, PersistentDataType.INTEGER, CURRENT_STAMINA_MODEL);
        // 古い版へ戻した場合にも読めるよう、互換用の倍率を併記する。
        pdc.set(enduranceKey, PersistentDataType.DOUBLE,
                safeMaxStamina / HorseStatMath.MODERN_BASE_STAMINA);
        pdc.set(baseSpeedKey, PersistentDataType.DOUBLE, Math.max(0.001, stats.baseMovementSpeed()));
    }

    void setBaseSpeed(Horse horse, double baseSpeed) {
        HorseStats current = getOrCreate(horse);
        apply(horse, new HorseStats(current.maxSpeedLevel(), current.maxStamina(), baseSpeed));
    }

    double awakeningChanceMultiplier(HorseStats stats) {
        return HorseStatMath.awakeningMultiplier(
                stats,
                minimumSpeedLevel(),
                maximumSpeedLevel(),
                HorseStatMath.minimumOriginalMaxStamina(),
                HorseStatMath.maximumOriginalMaxStamina(),
                plugin.getConfig().getDouble("awakening.low-stat-multiplier", 1.75),
                plugin.getConfig().getDouble("awakening.high-stat-multiplier", 0.35));
    }

    private Random randomFor(Horse horse) {
        long seed = horse.getUniqueId().getMostSignificantBits()
                ^ horse.getUniqueId().getLeastSignificantBits();
        return new Random(seed);
    }

    private int minimumSpeedLevel() {
        return Math.max(1, plugin.getConfig().getInt(
                "generated-stats.minimum-speed-level", 3));
    }

    private int maximumSpeedLevel() {
        return Math.max(minimumSpeedLevel(), plugin.getConfig().getInt(
                "generated-stats.maximum-speed-level", 6));
    }

}
