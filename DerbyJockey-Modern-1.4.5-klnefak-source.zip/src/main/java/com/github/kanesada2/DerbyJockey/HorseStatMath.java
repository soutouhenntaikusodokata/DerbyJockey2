package com.github.kanesada2.DerbyJockey;

import java.util.Random;
import java.util.UUID;

final class HorseStatMath {
    static final double ORIGINAL_MINIMUM_MODIFIER = 0.55;
    static final double ORIGINAL_MAXIMUM_MODIFIER = 1.0;
    static final double ORIGINAL_DECLARED_BAR_DRAIN_PER_SECOND = 0.005;
    static final double MODERN_DEFAULT_LEVEL_ONE_DRAIN_POINTS_PER_SECOND = 2.0;
    static final double MODERN_BASE_STAMINA =
            MODERN_DEFAULT_LEVEL_ONE_DRAIN_POINTS_PER_SECOND
                    / ORIGINAL_DECLARED_BAR_DRAIN_PER_SECOND;

    private HorseStatMath() {
    }

    static int middleBiasedInt(Random random, int minimum, int maximum) {
        if (maximum <= minimum) {
            return minimum;
        }
        double roll = middleBiasedRoll(random);
        return minimum + (int) Math.round(roll * (maximum - minimum));
    }

    static double originalStaminaModifier(UUID horseId, double maxHealth) {
        // 未改変版の9桁生成（短いhash値は最大体力を掛けて延ばす）を安全に再現する。
        long absoluteHash = Math.abs((long) horseId.hashCode());
        String numeric = Long.toString(absoluteHash);
        if (numeric.length() < 9) {
            int expanded = absoluteHash == 0L ? 1 : (int) absoluteHash;
            int expansionCount = 9 - numeric.length();
            double safeMaxHealth = maxHealth > 0.0 ? maxHealth : 30.0;
            for (int index = 0; index < expansionCount; index++) {
                expanded = (int) (expanded * safeMaxHealth);
            }
            numeric = Integer.toString(expanded);
        }
        if (numeric.startsWith("-")) {
            numeric = numeric.substring(1);
        }
        numeric = "0".repeat(Math.max(0, 9 - numeric.length())) + numeric;
        String specification = numeric.substring(numeric.length() - 9);
        int digitSum = 0;
        for (int index = 4; index < 9; index++) {
            digitSum += Character.digit(specification.charAt(index), 10);
        }
        return ORIGINAL_MAXIMUM_MODIFIER - digitSum / 100.0;
    }

    static double originalEffectiveMaxStamina(UUID horseId, double maxHealth) {
        return MODERN_BASE_STAMINA / originalStaminaModifier(horseId, maxHealth);
    }

    static double minimumOriginalMaxStamina() {
        return MODERN_BASE_STAMINA / ORIGINAL_MAXIMUM_MODIFIER;
    }

    static double maximumOriginalMaxStamina() {
        return MODERN_BASE_STAMINA / ORIGINAL_MINIMUM_MODIFIER;
    }

    static double staminaModifierFromCapacity(double maxStamina) {
        return MODERN_BASE_STAMINA / Math.max(1.0, maxStamina);
    }

    static double originalDeclaredDurationSeconds(double modifier) {
        double safeModifier = Math.max(ORIGINAL_MINIMUM_MODIFIER,
                Math.min(ORIGINAL_MAXIMUM_MODIFIER, modifier));
        return 1.0 / (ORIGINAL_DECLARED_BAR_DRAIN_PER_SECOND * safeModifier);
    }

    static double modernDefaultLevelOneDurationSeconds(double maxStamina) {
        return Math.max(0.0, maxStamina)
                / MODERN_DEFAULT_LEVEL_ONE_DRAIN_POINTS_PER_SECOND;
    }

    static double awakeningMultiplier(HorseStats stats,
                                      int minimumLevel, int maximumLevel,
                                      double minimumStamina, double maximumStamina,
                                      double lowStatMultiplier, double highStatMultiplier) {
        double levelQuality = normalize(stats.maxSpeedLevel(), minimumLevel, maximumLevel);
        double staminaQuality = normalize(stats.maxStamina(), minimumStamina, maximumStamina);
        double totalQuality = (levelQuality + staminaQuality) / 2.0;

        // 設定値が逆でも、低能力ほど高確率・高能力ほど低確率という仕様を守る。
        double easiest = Math.max(0.0, Math.max(lowStatMultiplier, highStatMultiplier));
        double hardest = Math.max(0.0, Math.min(lowStatMultiplier, highStatMultiplier));
        return easiest + (hardest - easiest) * totalQuality;
    }

    private static double middleBiasedRoll(Random random) {
        // バニラ馬の能力値と同様に、複数回の乱数を合成して両端より中央を出やすくする。
        return (random.nextDouble() + random.nextDouble() + random.nextDouble()) / 3.0;
    }

    private static double normalize(double value, double minimum, double maximum) {
        if (maximum <= minimum) {
            return 0.5;
        }
        return Math.max(0.0, Math.min(1.0, (value - minimum) / (maximum - minimum)));
    }
}
